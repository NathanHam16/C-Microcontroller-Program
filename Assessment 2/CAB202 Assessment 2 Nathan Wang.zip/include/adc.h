#include <avr/io.h>
#include <stdint.h>
#include <avr/interrupt.h>

void adc_init(void);