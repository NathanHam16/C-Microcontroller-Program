#include <avr/io.h>
#include <stdint.h>
#include <avr/interrupt.h>

void buttons_init(void);
void pb_init(void);
void get_index(void);