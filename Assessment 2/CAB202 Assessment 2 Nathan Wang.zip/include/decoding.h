#include <stdint.h>

uint32_t decode(uint32_t string);
uint8_t base64(char c);
uint8_t char_to_hex(char c);