#include <stdint.h>

void next(void);
void descramble(uint8_t *decoded);