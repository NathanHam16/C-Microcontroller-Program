#include <stdint.h>

void sequence_init(void);
void fetch_bytes(void);
void terminate_sequence(void);