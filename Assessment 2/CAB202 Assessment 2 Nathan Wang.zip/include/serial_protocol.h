#include <stdint.h>

void parser_service(void);
