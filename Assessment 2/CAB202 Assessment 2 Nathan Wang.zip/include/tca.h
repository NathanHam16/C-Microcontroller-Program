#include <avr/io.h>
#include <stdint.h>
#include <avr/interrupt.h>

void tca_init(void);
void tca_step(void);
