#include <stdint.h>

void test_mode(void);
uint8_t check_sum(void);
void execute_test(void);